<!-- source: https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/known-bugs -->
<!-- primary snapshot: 20240913183110  |  6 captures, 2 distinct content version(s) -->
<!-- other distinct versions retained in _versions/known-bugs/: 20170629125537 -->
# known-bugs

# **Known bugs / limitations**

______________________________________________________________________________________________________________

- **$COMPATIBILITY_0×07 mode :** unfinished. Breaks the gamma.

- **$WIDESCREEN command :** unfinished. No render fix…

- **Multi-disc support :** does not work properly with all games (not working with : [Final Fantasy IX](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-102#post-927043), [Grandia](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-100#post-920264)).

- **[POPS USB oddities :](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-109#post-950500)** we found out that latest USBD and USBHDFSD drivers reduced performances in BOTH POPStarter and POPS – so USBD and USBHDFSD drivers embedded into POPStarter are quite old. You can use your own USB modules (named as usbd.irx & usbhdfsd.irx, case sensitive, lowercase, no file size restriction) from mc#:/POPSTARTER – but expect lower performances.

- **[PS1 CD mode :](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-112#post-952852)** we found out after RIP 06 release that the HDD old launch type method (PP.PS1CD.ELF or __.PS1CD.ELF) has a bug : files from __common/POPS folder (and from __common/POPS/PS1CD) will not be loaded.

- **[PS3 support :](https://assemblergames.com/threads/ps2-pops-stuff-popstarter.45347/page-105#post-936970)** POPStarter test build works in a CECHA (no controller response on POPS tho).

- **[IGR :](https://www.metagames-eu.com/forums/playstation-2/popstarter-revision-13-a-48-134569.html#post1776443)** not working with a DS3 controller in BT mode (working in USB mode).

______________________________________________________________________________________________________________

### [**Index**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/index)
