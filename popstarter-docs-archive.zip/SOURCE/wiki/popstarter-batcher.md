<!-- source: https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/popstarter-batcher -->
<!-- primary snapshot: 20170813095246  |  10 captures, 3 distinct content version(s) -->
<!-- other distinct versions retained in _versions/popstarter-batcher/: 20170629142051, 20240907015427 -->
# popstarter-batcher

# [EXE] **POPStarter BATCHER v0.3.1**

______________________________________________________________________________________________________________

Note : 11/26/2016 – compatibility fix for WinXP (thanks to El_Patas for the report).

- **Download :** [here](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/downloads/BATCHER_0.3.1.EXE)

**How to use BATCHER_0.3.1.EXE ?**

**1.** Drop BATCHER_0.3.1.EXE where your .VCD are (recommended : either in your CUE2POPS folder, or in your POPS folder for USB and SMB modes) ;
**2.** Drop POPSTARTER.ELF in the same folder ;
**3.** Run BATCHER_0.3.1.EXE ;
**4.** Choose option :

**1**, **2** and **3** options are useful when you want to **create all launchers for your games at once**. These will create HDD or USB or SMB launchers (no prefix .ELFs or XX. prefix .ELFs or SB. prefix .ELFs) and VMC game folders, matching the .VCD files. If the VMC game folder already exists, it’s not overwritten.

**4** option is useful when a new POPSTARTER version is out. It will **update all game launchers at once** – same mode(s) as before the update.

**5** option exits the app.

______________________________________________________________________________________________________________

### [**Index**](https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/index)
