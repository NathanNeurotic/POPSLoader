POPStarter Documentation Archive  —  offline copy
=====================================================

This is a community-recovered, self-contained copy of the POPStarter documentation:
ShaolinAssassin's lost wiki (63 pages, recovered from the Internet Archive and merged
across snapshots), krHACKen's r13 changelog, the recovered downloads and menu images,
and a study of the official PSX-Place thread.

HOW TO USE
  Open  index.html  in any web browser to browse the whole site offline.
  (Full-text search needs the files served over http:// — most browsers block the
   local search-index fetch over file://. Browsing and all links work either way.)

WHAT'S INSIDE
  index.html, *.html, wiki/   the complete rendered site
  downloads/                  the recovered tools, builds, texture packs & CHEATS.TXT
  img/                        recovered menu / comparison images
  SOURCE/wiki/*.md            the raw recovered wiki markdown
  SOURCE/research/*           the cross-sourced corpus + the thread study

POLICY / LEGAL
  Contains NO Sony binaries. The POPS emulator (POPS.ELF, IOPRP252.IMG, POPS_IOX.PAK,
  POPS.PAK) is Sony-copyrighted and is NOT included anywhere in this archive — it is
  referenced by MD5 checksum only. POPStarter and POPSLoader are redistributable homebrew.

CREDITS
  ShaolinAssassin (the documentation), krHACKen (POPStarter), and the wider community.
  See credits.html. Live site: https://nathanneurotic.github.io/POPSLoader/
