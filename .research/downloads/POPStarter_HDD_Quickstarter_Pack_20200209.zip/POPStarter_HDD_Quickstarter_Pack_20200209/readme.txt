POPStarter - HDD Quickstarter Pack [2020/02/09 - update]:
---------------------------------------------------

Online tutorial version @https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/quickstart-hdd

~shaolinassassin, 2020/02/09

========================================
HDD Quickstarter Pack Changelog :
+ 2020/02/09 - POPStarter version updated to Rev 13 Beta (2019/06/05).
+ 2017/10/27 - POPStarter version updated to Rev 13 RIP 06.
+ 2017/01/10 - POPStarter version updated to Rev 13 WIP 05 OBT 16.
+ 2016/11/03 - CUE2POPS version updated to 2.3 (new release).
+ 2016/10/02 - POPStarter Quickstarter Pack HDD first version
========================================
POPStarter Official thread : [PS2] POPS stuff� @PSX-Place : https://www.psx-place.com/threads/popstarter-beta-from-2019-06-05.19139/
POPStarter wiki (documentation) : https://bitbucket.org/ShaolinAssassin/popstarter-documentation-stuff/wiki/Home